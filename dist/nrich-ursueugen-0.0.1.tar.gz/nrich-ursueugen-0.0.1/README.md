# nrichgenes
Performs gene enrichment analysis, for personal use. A wrapper for gseapy: https://pypi.org/project/gseapy/

# Usage example
TODO
